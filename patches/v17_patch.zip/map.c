#include "map.h"
#include "net.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define TILE_SIZE 256.0

static double clamp_lat(double lat) {
    if (lat > 85.05112878) return 85.05112878;
    if (lat < -85.05112878) return -85.05112878;
    return lat;
}

static double lon_to_world_x(double lon, int zoom) {
    double n = (double)(1u << zoom);
    return (lon + 180.0) / 360.0 * n * TILE_SIZE;
}

static double lat_to_world_y(double lat, int zoom) {
    double n = (double)(1u << zoom);
    double r = clamp_lat(lat) * M_PI / 180.0;
    double y = (1.0 - log(tan(r) + 1.0 / cos(r)) / M_PI) / 2.0;
    return y * n * TILE_SIZE;
}

int map_recommended_zoom(int radius_km) {
    if (radius_km <= 5) return 13;
    if (radius_km <= 10) return 12;
    if (radius_km <= 15) return 11;
    return 11;
}

void map_state_init(MapState *map) {
    if (!map) return;
    memset(map, 0, sizeof(*map));
    map->visual_scale = 1.0f;
}

void map_free(MapState *map) {
    if (!map) return;
    for (int i = 0; i < VFR_MAP_MAX_TILES; i++) {
        if (map->tiles[i].texture) {
            vita2d_free_texture(map->tiles[i].texture);
            map->tiles[i].texture = NULL;
        }
    }
    map->tile_count = 0;
    map->loaded_count = 0;
}

static vita2d_texture *decode_tile(const void *data, size_t size) {
    if (!data || size < 8) return NULL;
    const unsigned char *b = (const unsigned char *)data;
    if (b[0] == 0xFF && b[1] == 0xD8)
        return vita2d_load_JPEG_buffer(data, (unsigned long)size);
    if (b[0] == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G')
        return vita2d_load_PNG_buffer(data);
    return NULL;
}

static vita2d_texture *download_tile(int z, int x, int y, long *last_http, int *last_rc) {
    static const char *hosts[] = {
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile",
        "https://clarity.maptiles.arcgis.com/ArcGIS/rest/services/World_Imagery/MapServer/tile"
    };

    char url[320];
    for (int attempt = 0; attempt < 2; attempt++) {
        snprintf(url, sizeof(url), "%s/%d/%d/%d", hosts[attempt], z, y, x);
        char *body = NULL;
        size_t body_size = 0;
        long http_status = 0;
        char error[96];
        int rc = vfr_http_get(url, &body, &body_size, &http_status, error, sizeof(error));
        if (last_http) *last_http = http_status;
        if (last_rc) *last_rc = rc;
        if (rc >= 0 && http_status == 200 && body && body_size > 64) {
            vita2d_texture *tex = decode_tile(body, body_size);
            vfr_http_free(body);
            if (tex) return tex;
        } else {
            vfr_http_free(body);
        }
    }
    return NULL;
}

int map_load_for_location_zoom(MapState *map,
                               double lat,
                               double lon,
                               int radius_km,
                               int zoom,
                               float view_x,
                               float view_y,
                               float view_w,
                               float view_h,
                               char *status,
                               size_t status_size) {
    if (!map) return -1;
    map_free(map);

    if (zoom < 1) zoom = 1;
    if (zoom > 17) zoom = 17;
    map->center_lat = lat;
    map->center_lon = lon;
    map->radius_km = radius_km;
    map->zoom = zoom;
    map->view_x = view_x;
    map->view_y = view_y;
    map->view_w = view_w;
    map->view_h = view_h;
    map->center_pixel_x = lon_to_world_x(lon, map->zoom);
    map->center_pixel_y = lat_to_world_y(lat, map->zoom);
    map->visual_scale = 1.0f;
    map->visual_offset_x = 0.0f;
    map->visual_offset_y = 0.0f;

    if (status && status_size) snprintf(status, status_size, "SATELLITE LOADING");

    double left_px = map->center_pixel_x - (double)view_w * 0.5;
    double right_px = map->center_pixel_x + (double)view_w * 0.5;
    double top_px = map->center_pixel_y - (double)view_h * 0.5;
    double bottom_px = map->center_pixel_y + (double)view_h * 0.5;

    int min_x = (int)floor(left_px / TILE_SIZE);
    int max_x = (int)floor(right_px / TILE_SIZE);
    int min_y = (int)floor(top_px / TILE_SIZE);
    int max_y = (int)floor(bottom_px / TILE_SIZE);
    int world_tiles = 1 << map->zoom;
    long last_http = 0;
    int last_rc = 0;

    for (int ty = min_y; ty <= max_y && map->tile_count < VFR_MAP_MAX_TILES; ty++) {
        if (ty < 0 || ty >= world_tiles) continue;
        for (int tx = min_x; tx <= max_x && map->tile_count < VFR_MAP_MAX_TILES; tx++) {
            int wrapped_x = tx % world_tiles;
            if (wrapped_x < 0) wrapped_x += world_tiles;

            MapTile *tile = &map->tiles[map->tile_count++];
            memset(tile, 0, sizeof(*tile));
            tile->x = wrapped_x;
            tile->y = ty;
            tile->zoom = map->zoom;
            tile->screen_x = view_x + view_w * 0.5f + (float)((double)tx * TILE_SIZE - map->center_pixel_x);
            tile->screen_y = view_y + view_h * 0.5f + (float)((double)ty * TILE_SIZE - map->center_pixel_y);
            tile->texture = download_tile(map->zoom, wrapped_x, ty, &last_http, &last_rc);
            if (tile->texture) {
                vita2d_texture_set_filters(tile->texture, SCE_GXM_TEXTURE_FILTER_LINEAR, SCE_GXM_TEXTURE_FILTER_LINEAR);
                map->loaded_count++;
            }
        }
    }

    if (map->loaded_count > 0) {
        if (status && status_size)
            snprintf(status, status_size, "SATELLITE %d/%d", map->loaded_count, map->tile_count);
        return map->loaded_count;
    }

    if (status && status_size) {
        if (last_http > 0) snprintf(status, status_size, "SATELLITE HTTP %ld", last_http);
        else snprintf(status, status_size, "SATELLITE NET %d", last_rc);
    }
    return -2;
}

int map_load_for_location(MapState *map,
                          double lat,
                          double lon,
                          int radius_km,
                          float view_x,
                          float view_y,
                          float view_w,
                          float view_h,
                          char *status,
                          size_t status_size) {
    return map_load_for_location_zoom(map, lat, lon, radius_km, map_recommended_zoom(radius_km),
                                      view_x, view_y, view_w, view_h, status, status_size);
}

void map_draw(const MapState *map) {
    if (!map) return;
    const float cx = map->view_x + map->view_w * 0.5f;
    const float cy = map->view_y + map->view_h * 0.5f;
    const float scale = map->visual_scale > 0.01f ? map->visual_scale : 1.0f;
    vita2d_enable_clipping();
    vita2d_set_clip_rectangle((int)map->view_x, (int)map->view_y,
                              (int)(map->view_x + map->view_w),
                              (int)(map->view_y + map->view_h));
    for (int i = 0; i < map->tile_count; i++) {
        const MapTile *tile = &map->tiles[i];
        if (tile->texture) {
            float x = cx + (tile->screen_x - cx) * scale + map->visual_offset_x;
            float y = cy + (tile->screen_y - cy) * scale + map->visual_offset_y;
            vita2d_draw_texture_scale(tile->texture, x, y, scale, scale);
        }
    }
    vita2d_disable_clipping();
}

void map_visual_zoom(MapState *map, float factor, float anchor_x, float anchor_y) {
    if (!map || factor <= 0.0f) return;
    float old_scale = map->visual_scale > 0.01f ? map->visual_scale : 1.0f;
    float new_scale = old_scale * factor;
    if (new_scale < 0.50f) new_scale = 0.50f;
    if (new_scale > 6.0f) new_scale = 6.0f;
    if (fabsf(new_scale - old_scale) < 0.0005f) return;

    const float cx = map->view_x + map->view_w * 0.5f;
    const float cy = map->view_y + map->view_h * 0.5f;
    float ratio = new_scale / old_scale;
    map->visual_offset_x = anchor_x - cx - (anchor_x - cx - map->visual_offset_x) * ratio;
    map->visual_offset_y = anchor_y - cy - (anchor_y - cy - map->visual_offset_y) * ratio;
    map->visual_scale = new_scale;
}

void map_reset_visual_zoom(MapState *map) {
    if (!map) return;
    map->visual_scale = 1.0f;
    map->visual_offset_x = 0.0f;
    map->visual_offset_y = 0.0f;
}

void map_geo_to_screen(const MapState *map, double lat, double lon, float *x, float *y) {
    if (!map || !x || !y) return;
    double px = lon_to_world_x(lon, map->zoom);
    double py = lat_to_world_y(lat, map->zoom);
    float bx = map->view_x + map->view_w * 0.5f + (float)(px - map->center_pixel_x);
    float by = map->view_y + map->view_h * 0.5f + (float)(py - map->center_pixel_y);
    const float cx = map->view_x + map->view_w * 0.5f;
    const float cy = map->view_y + map->view_h * 0.5f;
    const float scale = map->visual_scale > 0.01f ? map->visual_scale : 1.0f;
    *x = cx + (bx - cx) * scale + map->visual_offset_x;
    *y = cy + (by - cy) * scale + map->visual_offset_y;
}


double map_visible_radius_km(const MapState *map) {
    if (!map || map->zoom < 1) return 5.0;
    const double lat_rad = clamp_lat(map->center_lat) * M_PI / 180.0;
    const double scale = map->visual_scale > 0.01f ? (double)map->visual_scale : 1.0;
    const double meters_per_pixel = (156543.03392 * cos(lat_rad)) / ((double)(1u << map->zoom) * scale);
    const double half_w = (double)map->view_w * 0.5;
    const double half_h = (double)map->view_h * 0.5;
    const double corner_pixels = sqrt(half_w * half_w + half_h * half_h);
    double km = corner_pixels * meters_per_pixel / 1000.0;
    if (km < 1.0) km = 1.0;
    if (km > 460.0) km = 460.0;
    return km;
}

int map_rebase_high_quality(MapState *map,
                            double lat,
                            double lon,
                            int radius_km,
                            char *status,
                            size_t status_size) {
    if (!map || map->zoom < 1) return -1;

    const float scale = map->visual_scale > 0.01f ? map->visual_scale : 1.0f;
    const double effective_zoom = (double)map->zoom + log((double)scale) / log(2.0);
    int target_zoom = (int)ceil(effective_zoom - 0.000001);
    if (target_zoom < 1) target_zoom = 1;
    if (target_zoom > 17) target_zoom = 17;

    double residual = pow(2.0, effective_zoom - (double)target_zoom);
    if (residual < 0.50) residual = 0.50;
    if (residual > 1.00) residual = 1.00;

    if (target_zoom == map->zoom && fabs((double)scale - residual) < 0.02)
        return 0;

    MapState fresh;
    map_state_init(&fresh);
    int rc = map_load_for_location_zoom(&fresh, lat, lon, radius_km, target_zoom,
                                        map->view_x, map->view_y, map->view_w, map->view_h,
                                        status, status_size);
    if (rc < 0) {
        map_free(&fresh);
        return rc;
    }

    fresh.visual_scale = (float)residual;
    fresh.visual_offset_x = map->visual_offset_x;
    fresh.visual_offset_y = map->visual_offset_y;

    map_free(map);
    *map = fresh;
    return rc;
}
